package com.jesus.lunape.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jesus.lunape.model.Perfil;

public interface PerfilesRepository extends JpaRepository<Perfil, Integer> {

}

